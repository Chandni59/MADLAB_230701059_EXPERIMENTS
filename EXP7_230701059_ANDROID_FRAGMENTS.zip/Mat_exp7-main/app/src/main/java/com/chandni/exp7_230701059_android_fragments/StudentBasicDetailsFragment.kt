package com.chandni.exp7_230701059_android_fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class StudentBasicDetailsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_basic_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etName = view.findViewById<EditText>(R.id.etName)
        val etAge = view.findViewById<EditText>(R.id.etAge)
        val etAddress = view.findViewById<EditText>(R.id.etAddress)
        val btnSubmit = view.findViewById<Button>(R.id.btnSubmitDetails)
        val tvResult = view.findViewById<TextView>(R.id.tvDetailsResult)

        btnSubmit.setOnClickListener {
            val name = etName.text.toString().trim()
            val ageStr = etAge.text.toString().trim()
            val address = etAddress.text.toString().trim()

            if (name.isEmpty() || ageStr.isEmpty() || address.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val result = "Student Details\n\nName : $name\nAge   : $ageStr\nAddress : $address"
            tvResult.text = result
        }
    }
}
