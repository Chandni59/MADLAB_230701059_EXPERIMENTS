package com.chandni.exp7_230701059_android_fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class StudentMarkFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_student_mark, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etMark1 = view.findViewById<EditText>(R.id.etMark1)
        val etMark2 = view.findViewById<EditText>(R.id.etMark2)
        val etMark3 = view.findViewById<EditText>(R.id.etMark3)
        val btnCalculate = view.findViewById<Button>(R.id.btnCalculate)
        val tvTotal = view.findViewById<TextView>(R.id.tvTotal)
        val tvGrade = view.findViewById<TextView>(R.id.tvGrade)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)

        btnCalculate.setOnClickListener {
            val m1 = etMark1.text.toString().toIntOrNull()
            val m2 = etMark2.text.toString().toIntOrNull()
            val m3 = etMark3.text.toString().toIntOrNull()

            if (m1 == null || m2 == null || m3 == null) {
                Toast.makeText(requireContext(), "Please enter all marks", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (m1 !in 0..100 || m2 !in 0..100 || m3 !in 0..100) {
                Toast.makeText(requireContext(), "Marks must be between 0 and 100", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val total = m1 + m2 + m3
            val average = total / 3.0

            val grade = when {
                average >= 90 -> "A+"
                average >= 80 -> "A"
                average >= 70 -> "B"
                average >= 60 -> "C"
                average >= 50 -> "D"
                average >= 35 -> "E"
                else -> "F"
            }

            val status = if (m1 >= 35 && m2 >= 35 && m3 >= 35) "PASS" else "FAIL"

            tvTotal.text = "Total : $total / 300  (Average: ${"%.2f".format(average)})"
            tvGrade.text = "Grade : $grade"
            tvStatus.text = "Status : $status"
        }
    }
}
