package com.example.calculator   // ⚠ Replace with your actual package

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val num1 = findViewById<EditText>(R.id.editNum1)
        val num2 = findViewById<EditText>(R.id.editNum2)
        val result = findViewById<TextView>(R.id.textResult)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSub = findViewById<Button>(R.id.btnSub)
        val btnMul = findViewById<Button>(R.id.btnMul)
        val btnDiv = findViewById<Button>(R.id.btnDiv)

        fun getNumbers(): Pair<Double, Double>? {
            if (num1.text.isEmpty() || num2.text.isEmpty()) {
                Toast.makeText(this, "Enter both numbers", Toast.LENGTH_SHORT).show()
                return null
            }
            return Pair(num1.text.toString().toDouble(), num2.text.toString().toDouble())
        }

        btnAdd.setOnClickListener {
            getNumbers()?.let {
                result.text = "Result: ${it.first + it.second}"
            }
        }

        btnSub.setOnClickListener {
            getNumbers()?.let {
                result.text = "Result: ${it.first - it.second}"
            }
        }

        btnMul.setOnClickListener {
            getNumbers()?.let {
                result.text = "Result: ${it.first * it.second}"
            }
        }

        btnDiv.setOnClickListener {
            getNumbers()?.let {
                if (it.second == 0.0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
                } else {
                    result.text = "Result: ${it.first / it.second}"
                }
            }
        }
    }
}