package com.chandni.studentview

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etAge: EditText
    private lateinit var rgColour: RadioGroup
    private lateinit var etBiography: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etAge = findViewById(R.id.etAge)
        rgColour = findViewById(R.id.rgColour)
        etBiography = findViewById(R.id.etBiography)
        btnSave = findViewById(R.id.btnSave)

        loadProfile()

        btnSave.setOnClickListener { saveProfile() }
    }

    private fun prefs() =
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun loadProfile() {
        val p = prefs()
        etName.setText(p.getString(KEY_NAME, ""))
        etEmail.setText(p.getString(KEY_EMAIL, ""))
        etAge.setText(p.getString(KEY_AGE, ""))
        etBiography.setText(p.getString(KEY_BIO, ""))

        val colourId = when (p.getString(KEY_COLOUR, null)) {
            "Red" -> R.id.rbRed
            "Green" -> R.id.rbGreen
            "Blue" -> R.id.rbBlue
            "Yellow" -> R.id.rbYellow
            else -> -1
        }
        if (colourId != -1) rgColour.check(colourId) else rgColour.clearCheck()
    }

    private fun saveProfile() {
        val colour = when (rgColour.checkedRadioButtonId) {
            R.id.rbRed -> "Red"
            R.id.rbGreen -> "Green"
            R.id.rbBlue -> "Blue"
            R.id.rbYellow -> "Yellow"
            else -> ""
        }

        prefs().edit {
            putString(KEY_NAME, etName.text.toString().trim())
            putString(KEY_EMAIL, etEmail.text.toString().trim())
            putString(KEY_AGE, etAge.text.toString().trim())
            putString(KEY_COLOUR, colour)
            putString(KEY_BIO, etBiography.text.toString())
        }

        Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val PREFS_NAME = "user_profile"
        private const val KEY_NAME = "name"
        private const val KEY_EMAIL = "email"
        private const val KEY_AGE = "age"
        private const val KEY_COLOUR = "favourite_colour"
        private const val KEY_BIO = "biography"
    }
}
