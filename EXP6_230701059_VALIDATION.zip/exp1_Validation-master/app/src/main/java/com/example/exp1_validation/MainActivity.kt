package com.example.exp1_validation
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class ASS7 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameField = findViewById<EditText>(R.id.editUsername)
        val idField = findViewById<EditText>(R.id.editID)
        val validateBtn = findViewById<Button>(R.id.btnValidate)

        validateBtn.setOnClickListener {

            val username = usernameField.text.toString().trim()
            val id = idField.text.toString().trim()

            // i) Check empty fields
            if (username.isEmpty() || id.isEmpty()) {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ii) Username validation (alphabets only)
            val namePattern = Regex("^[A-Za-z]+$")
            if (!username.matches(namePattern)) {
                Toast.makeText(this, "Username must contain alphabets only", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // iii) ID validation (exactly 4 digits)
            val idPattern = Regex("^[0-9]{4}$")
            if (!id.matches(idPattern)) {
                Toast.makeText(this, "ID must be exactly 4 digits", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "Validation Successful!", Toast.LENGTH_SHORT).show()
        }
    }
}